#!/data/data/com.termux/files/usr/bin/bash

pdir=$HOME/.awnto
pfol=rnx-d
pfll=$pdir/$pfol

mkdir -p $pfll

cd $pdir

log=$pfol/im/vari/lstat.txt

sleep 2


./$pfol/fil/rcv.sh &


echo "starting ..." > $log

pulseaudio --start &

./$pfol/fil/im.sh /awnto/im/boot -l >> $log



echo "-------------" >> $log
echo " End Reached" >> $log
echo "-------------" >> $log

echo "" >> $log
echo "" >> $log

while true
do
	sleep 1
	#echo  >> $log
done
