#!/data/data/com.termux/files/usr/bin/bash

pdir=$HOME/.awnto
pfol=rnx-d
pfll=$pdir/$pfol

mkdir -p $pfll

cd $pdir

clear

cat $pfol/fil/rcv/profile.txt

$PREFIX/bin/rnx auto
# >> /dev/null


