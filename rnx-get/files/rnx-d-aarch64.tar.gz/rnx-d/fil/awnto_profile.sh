#!/data/data/com.termux/files/usr/bin/bash

pdir=$HOME/.awnto
pfol=rnx-d
pfll=$pdir/$pfol

mkdir -p $pfll

cd $pdir


: << '###'

$status=`cat $pfol/im/vari/rnx_rfl`
$cofi=$pfol/im/vari/confi

if test -f $confi && test -f $status ;
then
if [ `cat $confi` == 'done' && `cat $status` == 'done'  ] ;


echo "all set dear"

then
fi
fi

###


$PREFIX/bin/rnx boot
# >> /dev/null


