#!/data/data/com.termux/files/usr/bin/bash

pdir=$HOME/.awnto
pfol=rnx-d
pfll=$pdir/$pfol

mkdir -p $pfll

cd $pdir

log=$pfol/im/vari/lstat.txt


exec ./$pfol/fil/preboot.sh > $log



