#!/data/data/com.termux/files/usr/bin/bash

pdir=$HOME/.awnto
pfol=rnx-d
pfll=$pdir/$pfol

mkdir -p $pfll

cd $pdir



cat $pfol/fil/rcv/welcome.txt


