#!/data/data/com.awnto.rinix.io/files/usr/kbin/bash



pdir=$HOME/.awnto
pfol=rnx-d
pfll=$pdir/$pfol

cd $pdir

rdu=`cat $pfol/im/vari/rdu`
rnx_rfl=`cat $pfol/im/vari/rnx_rfl`
#cd $(dirname $0)
## unset LD_PRELOAD in case termux-exec is installed
unset LD_PRELOAD
command="proot"
command+=" --link2symlink"
command+=" -0 --sysvipc"
command+=" -r $rnx_rfl"
if [ -n "$(ls -A $pfol/im-binds)" ]; then
    for f in debian-binds/* ;do
      . $f
    done
fi
command+=" -b /dev"
command+=" -b /proc"


#command+=" -b /plat_property_contexts" 
#command+=" -b /data/dalvik-cache" 
#command+=" -b /data/data/com.termux/files/usr" 
command+=" -b /data"
command+=" -b $HOME/fatmx/com.termux:/data/data/com.termux"
#command+=" -b /dev" 
#command+=" -b /proc" 
#command+=" -b /storage" 
#command+=" -b /sys" 
command+=" -b /system" 
command+=" -b /vendor"

#/data/data/com.termux/files
#command+=" -b /data/data/com.termux/files/awnto/tmp:/tmp"

command+=" -b /sdcard:/awnto/sdcard"
command+=" -b /storage:/awnto/shared/storage"
#command+=" -b /sdcard:/home/$rdu/sdcard"
#command+=" -b /sdcard/AWN:/home/$rdu/AWN"
command+=" -b /data/data/com.awnto.rinix.io/files:/awnto/shared/k9rnx"


command+=" -b $pfol/im:/awnto/im"
command+=" -b $rnx_rfl/root:/dev/shm"
## uncomment the following line to have access to the home directory of termux
#command+=" -b /data/data/com.termux/files/home:/root"
## uncomment the following line to mount /sdcard directly to / 
#command+=" -b /sdcard"
command+=" -w /root"
command+=" /usr/bin/env -i"
command+=" HOME=/root"


command+=" ANDROID_DATA=/data" 
command+=" ANDROID_ROOT=/system"


command+=" PATH=/usr/local/sbin:/usr/local/bin:/bin:/usr/bin:/sbin:/usr/sbin:/usr/games:/usr/local/games"
command+=" TERM=$TERM"
command+=" LANG=C.UTF-8"
command+=" /bin/bash --login"
com="$@"
if [ -z "$1" ];then
    exec $command
else
    $command -c "$com"
fi
