#!/data/data/com.termux/files/usr/bin/bash

pdir=$HOME/.awnto
pfol=rnx-d
pfll=$pdir/$pfol

mkdir -p $pfll

cd $pdir

log=$pfol/im/vari/lstat.txt

#sleep 2


./$pfol/fil/rcv.sh &


echo "starting ..."

pulseaudio --start &

./$pfol/fil/im.sh /awnto/im/boot -l



echo "-------------"
echo " End Reached"
echo "-------------"

echo ""
echo ""

while true
do
	sleep 1
	#echo 
done
